# Changelog

## 0.1.0

- Initial headless client, in-memory session and Lit Web Component.
