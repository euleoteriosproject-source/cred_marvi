# @atrium/sdk-js

Official framework-agnostic Atrium browser SDK. It provides a headless client and an accessible Lit Web Component. It never decides journey navigation and never accesses a database or identity provider.

```ts
import { createAtriumClient } from "@atrium/sdk-js";
const client = createAtriumClient({
  baseUrl: "https://api.example.test",
  publicKey: "pk_public",
});
const session = await client.start({
  flowKey: "public-onboarding",
  locale: "pt-BR",
});
await session.answer(session.publicState.question!.id, "plain text");
```

The opaque token exists only in private `ConversationSession` memory. Refresh loses the session. Answers are never stored. `dispose()` aborts pending work and erases the token reference. When `answer()` reaches logical completion, call `complete()` to confirm backend completion/outbox before treating the UI as completed.

```html
<atrium-conversation
  public-key="pk_public"
  flow="public-onboarding"
  locale="pt-BR"
></atrium-conversation>
<script type="module">
  import { defineAtriumConversation } from "@atrium/sdk-js/web-component";
  defineAtriumConversation();
</script>
```

The CDN entry auto-registers; other entry points do not. Modes are `inline`, `modal`, and `floating`. Theme variables are `--atrium-color-primary`, `--atrium-color-primary-contrast`, `--atrium-color-text`, `--atrium-color-background`, `--atrium-color-error`, `--atrium-color-border`, `--atrium-color-backdrop`, `--atrium-focus-ring`, `--atrium-radius`, and `--atrium-font`.

`messages` accepts safe partial overrides for labels such as loading, completed, continue, open/close, select placeholder, consent, boolean yes, progress, retry and generic errors. The component does not display raw transport errors, Problem Details bodies, trace ids, tokens or stack traces.

Canonical events use `atrium:event`; UI-only events are `atrium-ui:opened` and `atrium-ui:closed`. Events never contain answers, token, or PII. `answer()` is never retried. GET, start and complete have bounded transient retry; start and complete reuse one idempotency key. A 429 requires `Retry-After`.

Runtime responses are checked by deterministic standalone validators generated from the canonical `atrium-common` JSON Schemas. Ajv is build tooling only and is absent from browser runtime code.

Bundle target is 80 KB gzip and hard limit is 120 KB gzip per entry. Measurements are written to `dist/bundle-report.json`.
