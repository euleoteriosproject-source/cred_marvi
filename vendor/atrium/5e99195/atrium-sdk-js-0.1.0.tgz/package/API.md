# API reference

- `createAtriumClient(options)`: SSR-safe client without element registration.
- `AtriumClient.getConfiguration/start/answer/complete/getStatus`.
- `ConversationSession.answer/complete/getStatus/dispose`.
- `defineAtriumConversation()`: idempotently registers `<atrium-conversation>`.

Operations accept `AbortSignal`. Configuration accepts timeout, injected fetch and bounded retry settings. Typed errors extend `AtriumSdkError`; HTTP errors expose canonical Problem Details only after validation.
