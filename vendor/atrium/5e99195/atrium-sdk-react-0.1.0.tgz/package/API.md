# API reference

Root `@atrium/sdk-react`: version, public types, canonical contract types and SDK JS error classes.

Client `@atrium/sdk-react/client`: `AtriumProvider`, `AtriumConversation`, `useAtrium`, `useAtriumConfiguration`, and `useAtriumConversation`.

`AtriumConversation` supports `inline`, `modal`, and `floating`; it attaches canonical and UI listeners before dynamically registering the existing SDK JS Web Component.
