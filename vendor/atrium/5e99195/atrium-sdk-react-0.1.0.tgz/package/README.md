# @atrium/sdk-react

Thin React 19 bindings over `@atrium/sdk-js`. The React package does not implement HTTP, retry, tokens, contracts or flow navigation.

## Client boundary

```tsx
"use client";
import { AtriumConversation, AtriumProvider } from "@atrium/sdk-react/client";

export function Journey() {
  return (
    <AtriumProvider
      baseUrl={process.env.NEXT_PUBLIC_ATRIUM_API_URL!}
      publicKey={process.env.NEXT_PUBLIC_ATRIUM_PUBLIC_KEY!}
      flow="public-onboarding"
      locale="pt-BR"
    >
      <AtriumConversation mode="inline" />
    </AtriumProvider>
  );
}
```

Only a public integration key may be exposed to the browser. Administrative secrets must never use `NEXT_PUBLIC_*`.

The root entry exports types, version and SDK error classes without browser side effects. Provider, hooks and wrapper live in `@atrium/sdk-react/client`, whose distributed entry preserves `"use client"` for Next App Router.

## Hooks and ownership

`useAtriumConfiguration()` loads cancelably. `useAtriumConversation()` exposes explicit `start`, `answer`, `complete`, `refresh` and `dispose`. A session created by the hook is owned and disposed on unmount. A supplied external session is never automatically disposed. Conversation start is explicit, preventing StrictMode effects from creating conversations.

## Events and styles

Canonical `atrium:event` values map to `onReady`, `onStarted`, `onQuestionPresented`, `onCompleted` and `onError`. UI-only open/close map separately. Callback payloads are reduced to canonical metadata and never contain tokens or answers.

`styleOverrides` accepts only known local CSS variables through `AtriumStyleOverrides`; it is not a platform Theme contract. HTML, CSS strings, scripts and style URLs are not accepted. `messages` is forwarded to the Web Component as safe label overrides; callbacks still never include tokens, answers or PII.

For optional client-only loading, use `next/dynamic` from the consuming Next application. No Next private API is required.
