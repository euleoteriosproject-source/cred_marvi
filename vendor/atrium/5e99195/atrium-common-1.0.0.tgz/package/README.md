# @atrium/common

Canonical external contracts for Atrium. OpenAPI 3.1 lives in `openapi`; JSON Schema 2020-12 lives in `schemas`. Files under `src/generated` are derived artifacts and must not be edited manually.

## Contract policy

- JSON Schema with strict Ajv validation is the runtime authority.
- OpenAPI references canonical JSON Schemas.
- TypeScript output is generated and checked for drift. Zod may be added only after passing the fidelity gate.
- Text fields are plain text; consumers must never render them as HTML.
- Contract SemVer is independent from a flow's content version.
- Breaking changes require a major release; additive optional fields require a minor release; compatible corrections use a patch release.
- Deprecated operations and fields remain available for a documented migration period. Future HTTP deprecation uses `Deprecation`, `Sunset`, and `Link` headers.
- Published `FlowVersion` content is immutable.
- Question summary flags default to `false`. A value is eligible for a summary only when `includeInSummary` is `true` and `sensitive` is `false`; intrinsically sensitive document types remain excluded by the engine.

Zod generation is currently deferred by ADR 0005: the evaluated generator weakened cross-schema references to `z.any()`. Ajv remains the sole runtime validator; no manual Zod mirror is maintained.

## Commands

```text
pnpm validate
pnpm generate
pnpm generate:check
pnpm typecheck
pnpm test
pnpm build
pnpm check
```
