# Proprietary software — all rights reserved

Copyright (c) Grupo Marvi.

This source code is proprietary and unlicensed for copying, modification, distribution, or use except with explicit written permission from the copyright holder.
